import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

app.disable('x-powered-by');
app.use(express.json({ limit: '50kb' }));
app.use((_req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});

// Initialize server-side Gemini client with required User-Agent
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// ── AI chatbot ("Evans") ─────────────────────────────────────────────────────
// Simple in-memory rate limit: 20 requests / minute / IP.
const hits = new Map<string, number[]>();
const limited = (ip: string) => {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 60000);
  list.push(now);
  hits.set(ip, list);
  return list.length > 20;
};

const str = (v: unknown, max: number) => (typeof v === 'string' ? v.slice(0, max) : '');

app.post('/api/chat', async (req, res) => {
  try {
    if (limited(req.ip || 'unknown')) {
      return res.status(429).json({ error: 'Too many requests' });
    }

    const rawMessages = Array.isArray(req.body?.messages) ? req.body.messages.slice(-12) : [];
    const messages = rawMessages
      .map((m: { role?: string; content?: string }) => ({ role: m?.role === 'assistant' ? 'assistant' : 'user', content: str(m?.content, 1000) }))
      .filter((m: { content: string }) => m.content.trim());
    const userMessage = messages[messages.length - 1]?.content || '';
    if (!userMessage) return res.status(400).json({ error: 'Message content is required' });

    // Business facts come from the website (Firestore) via the client. Nothing is invented here.
    const ctx = req.body?.siteContext || {};
    const company = str(ctx.companyName, 80) || 'EMG WEB SOLUTIONS';
    const phone = str(ctx.phone, 30) || '0142201120';
    const whatsapp = str(ctx.whatsapp, 30) || phone;
    const email = str(ctx.email, 100) || 'contact@emgwebsolutions.com';
    const motto = str(ctx.motto, 100) || 'Your Vision, Our Code!';
    const services = (Array.isArray(ctx.services) ? ctx.services : []).slice(0, 20).map((s: Record<string, unknown>) => ({
      name: str(s.name, 80), price: str(s.price, 40), delivery: str(s.delivery, 60), description: str(s.description, 300),
      features: Array.isArray(s.features) ? s.features.slice(0, 8).map((f) => str(f, 80)) : [],
    }));
    const portfolio = (Array.isArray(ctx.portfolio) ? ctx.portfolio : []).slice(0, 15).map((p: Record<string, unknown>) => ({
      title: str(p.title, 80), category: str(p.category, 60), url: str(p.url, 200),
    }));

    const systemInstruction = `You are Evans, the friendly and professional virtual assistant for ${company} (${motto}), a web design and digital solutions business.

FACTS YOU MAY USE (this is the only source of truth about the business):
- WhatsApp: ${whatsapp}. Phone: ${phone}. Email: ${email}.
- Services and prices (Kenyan Shillings, KSh): ${JSON.stringify(services)}
- Completed projects: ${JSON.stringify(portfolio)}

RULES:
1. Introduce yourself as "Evans, the ${company} virtual assistant" when greeting. Never mention which AI model, company or technology powers you; if asked, say you are the ${company} virtual assistant.
2. Never invent services, prices, discounts, clients, reviews, statistics, awards, office addresses or delivery times. If a price says "Custom quote" or the information is not listed, say the team will prepare a quotation and invite the visitor to share details or message on WhatsApp (${whatsapp}).
3. Always quote prices in KSh exactly as listed. Never use dollars.
4. Help visitors understand services, request a quotation, request a consultation, and contact the team. Encourage them to use the contact form or WhatsApp when they are ready.
5. Be warm, concise (under 110 words unless more detail is needed) and use short paragraphs or a few bullet points.
6. Stay on topic (websites, digital services, EMG). Politely decline unrelated requests.`;

    const serviceLines = services.length
      ? services.map((s: { name: string; price: string }) => `• ${s.name}${s.price ? ` — ${s.price}` : ''}`).join('\n')
      : '• Website development, redesign, e-commerce, landing pages, SEO and social media management';

    const fallbackReply = (q: string) => {
      const lower = q.toLowerCase();
      if (/(price|cost|how much|rate|package|quote|quotation)/.test(lower)) {
        return `Here are our services and pricing (KSh):\n${serviceLines}\n\nFor an exact quotation, tell us about your project on WhatsApp (${whatsapp}) or use the contact form on this page.`;
      }
      if (/(phone|call|contact|whatsapp|reach|number|email)/.test(lower)) {
        return `You can reach ${company} on WhatsApp or phone at ${whatsapp}, or by email at ${email}.`;
      }
      if (/(work|portfolio|project|example)/.test(lower)) {
        return portfolio.length
          ? `Some of our projects: ${portfolio.map((p: { title: string }) => p.title).join(', ')}. You can see them in the Selected Projects section.`
          : `Our Selected Projects section shows our work. For examples relevant to your industry, message us on WhatsApp (${whatsapp}).`;
      }
      if (/(consult|book|meeting|appointment)/.test(lower)) {
        return `We'd be glad to arrange a consultation. Message us on WhatsApp (${whatsapp}) or send your details through the contact form and we'll get back to you.`;
      }
      return `Hello! I'm Evans, the ${company} virtual assistant. We offer:\n${serviceLines}\n\nHow can I help you today?`;
    };

    const key = process.env.GEMINI_API_KEY;
    const hasValidKey = key && key !== 'MY_GEMINI_API_KEY' && key.length > 10;

    if (ai && hasValidKey) {
      try {
        const response = await ai.models.generateContent({
          model: process.env.GEMINI_MODEL || 'gemini-3.8-flash',
          contents: messages.map((m: { role: string; content: string }) => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })),
          config: { systemInstruction },
        });
        return res.json({ reply: response.text || fallbackReply(userMessage) });
      } catch (err) {
        console.warn('AI request failed; using built-in reply:', err instanceof Error ? err.message : err);
      }
    }
    return res.json({ reply: fallbackReply(userMessage) });
  } catch (error) {
    console.error('Chat endpoint error:', error);
    return res.json({ reply: "Thanks for reaching out! For quick help, please message our team on WhatsApp or use the contact form on this page." });
  }
});

// Setup Vite in development or serve static in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`EMG Web Solutions server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
