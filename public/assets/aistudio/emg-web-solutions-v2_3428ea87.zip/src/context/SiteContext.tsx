import React, { createContext, useContext, useEffect, useMemo, useRef, useState, useCallback } from 'react';
import {
  collection, doc, onSnapshot, setDoc, deleteDoc, getDoc, query, where, arrayUnion, QuerySnapshot, DocumentData,
} from 'firebase/firestore';
import { signInWithPopup, signOut, onAuthStateChanged, GoogleAuthProvider, User } from 'firebase/auth';
import { db, auth, ADMIN_EMAILS, explainError } from '../firebase';
import { Project, Service, GoogleReview, SiteSettings, ReviewStatus, EstimatorConfig } from '../types';
import { DEFAULT_SITE_SETTINGS, DEFAULT_SERVICES, DEFAULT_PORTFOLIO, DEFAULT_ESTIMATOR, isDemoContent, isLegacyHeroCopy } from '../data/defaultData';
import { clean } from '../lib/format';

export interface Inquiry { id: string; name: string; phone: string; email: string; service: string; budget: string; message: string; createdAt: string }
export type AdminTab = 'dashboard' | 'content' | 'services' | 'portfolio' | 'reviews' | 'inquiries' | 'estimator' | 'settings' | 'backup';
export interface ReviewInput { authorName: string; rating: number; serviceReviewed: string; reviewText: string }
export interface InquiryInput { name: string; phone: string; email: string; service: string; budget: string; message: string }

interface SiteContextType {
  settings: SiteSettings;
  estimator: EstimatorConfig;
  services: Service[];
  portfolio: Project[];
  reviews: GoogleReview[];
  inquiries: Inquiry[];
  isLoading: boolean;
  isFirebaseConnected: boolean;
  updateSettings: (patch: Partial<SiteSettings>) => Promise<void>;
  saveService: (s: Omit<Service, 'id'> & { id?: string }) => Promise<void>;
  deleteService: (id: string) => Promise<void>;
  saveProject: (p: Omit<Project, 'id'> & { id?: string }) => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  submitReview: (r: ReviewInput) => Promise<void>;
  addManualReview: (r: Omit<GoogleReview, 'id'>) => Promise<void>;
  updateReview: (id: string, patch: Partial<GoogleReview>) => Promise<void>;
  deleteReview: (id: string) => Promise<void>;
  submitInquiry: (i: InquiryInput) => Promise<void>;
  deleteInquiry: (id: string) => Promise<void>;
  seedStarterContent: () => Promise<number>;
  exportBackup: () => string;
  importBackup: (json: string) => Promise<number>;
  isAdminOpen: boolean;
  setIsAdminOpen: (o: boolean) => void;
  activeAdminTab: AdminTab;
  setActiveAdminTab: (t: AdminTab) => void;
  currentUser: User | null;
  isAdmin: boolean;
  isAuthChecking: boolean;
  loginWithGoogle: () => Promise<void>;
  logoutUser: () => Promise<void>;
}

const Ctx = createContext<SiteContextType | undefined>(undefined);
const CACHE = { settings: 'emg_cache_settings_v3', services: 'emg_cache_services_v3', portfolio: 'emg_cache_portfolio_v3', reviews: 'emg_cache_reviews_v3' };

const readCache = <T,>(k: string): T | null => { try { const v = localStorage.getItem(k); return v ? (JSON.parse(v) as T) : null; } catch { return null; } };
const writeCache = (k: string, v: unknown) => { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* storage full or blocked */ } };
const strip = <T,>(o: T): T => JSON.parse(JSON.stringify(o));
const rid = () => `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
const toList = <T,>(snap: QuerySnapshot<DocumentData>) => snap.docs.map((d) => ({ ...d.data(), id: d.id }) as T);
/** Runs a Firestore write; turns errors AND silent hangs (e.g. offline) into a readable error. */
const wrap = async <T,>(fn: () => Promise<T>, timeoutMs = 15000): Promise<T> => {
  let timer: ReturnType<typeof setTimeout> | undefined;
  const timeout = new Promise<never>((_, rej) => { timer = setTimeout(() => rej(new Error('No response from Firebase. Check your internet connection and try again.')), timeoutMs); });
  try { return await Promise.race([fn(), timeout]); }
  catch (e) { throw new Error((e as Error).message === 'No response from Firebase. Check your internet connection and try again.' ? (e as Error).message : explainError(e)); }
  finally { clearTimeout(timer); }
};

/** Client-side abuse guard for public forms (rules still validate shape/size server-side). */
function throttle(key: string, minGapMs: number, maxPerDay: number) {
  let log: number[] = [];
  try { log = JSON.parse(localStorage.getItem(key) || '[]'); } catch { /* ignore */ }
  const now = Date.now();
  log = log.filter((t) => now - t < 86400000);
  if (log.length && now - log[log.length - 1] < minGapMs) throw new Error('Please wait a moment before submitting again.');
  if (log.length >= maxPerDay) throw new Error('Submission limit reached for today. Please contact us on WhatsApp instead.');
  log.push(now);
  try { localStorage.setItem(key, JSON.stringify(log)); } catch { /* ignore */ }
}

export const SiteProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [rawSettings, setRawSettings] = useState<Partial<SiteSettings> | null>(() => readCache(CACHE.settings));
  const [rawServices, setRawServices] = useState<Service[] | null>(() => readCache(CACHE.services));
  const [rawPortfolio, setRawPortfolio] = useState<Project[] | null>(() => readCache(CACHE.portfolio));
  const [rawReviews, setRawReviews] = useState<GoogleReview[] | null>(() => readCache(CACHE.reviews));
  const [inquiries, setInquiries] = useState<Inquiry[]>([]);
  const [loaded, setLoaded] = useState({ settings: false, services: false, portfolio: false, reviews: false });
  const [timedOut, setTimedOut] = useState(false);
  const [isFirebaseConnected, setConnected] = useState(true);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [activeAdminTab, setActiveAdminTab] = useState<AdminTab>('dashboard');
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [isAuthChecking, setAuthChecking] = useState(true);
  const settingsRef = useRef<Partial<SiteSettings> | null>(null);
  settingsRef.current = rawSettings;

  // ── Auth + admin check (email allow-list, or a document in /admins/{uid}) ──
  useEffect(() => onAuthStateChanged(auth, async (user) => {
    setCurrentUser(user);
    if (!user) { setIsAdmin(false); setAuthChecking(false); return; }
    let ok = Boolean(user.email && user.emailVerified && ADMIN_EMAILS.includes(user.email.toLowerCase()));
    if (!ok) { try { ok = (await getDoc(doc(db, 'admins', user.uid))).exists(); } catch { ok = false; } }
    setIsAdmin(ok); setAuthChecking(false);
  }), []);

  useEffect(() => { const t = setTimeout(() => setTimedOut(true), 6000); return () => clearTimeout(t); }, []);

  // ── Realtime listeners. They only READ; nothing is ever auto-written from defaults. ──
  useEffect(() => {
    const done = (k: keyof typeof loaded) => setLoaded((l) => (l[k] ? l : { ...l, [k]: true }));
    const fail = (k: keyof typeof loaded) => (e: Error) => { console.warn(`Firestore ${k} listener:`, e.message); setConnected(false); done(k); };
    const unsubs = [
      onSnapshot(doc(db, 'settings', 'global'), (s) => {
        setConnected(true);
        if (s.exists()) { const d = s.data() as Partial<SiteSettings>; setRawSettings(d); writeCache(CACHE.settings, d); }
        done('settings');
      }, fail('settings')),
      onSnapshot(collection(db, 'services'), (s) => { const l = toList<Service>(s); setRawServices(l); writeCache(CACHE.services, l); done('services'); }, fail('services')),
      onSnapshot(collection(db, 'portfolio'), (s) => { const l = toList<Project>(s); setRawPortfolio(l); writeCache(CACHE.portfolio, l); done('portfolio'); }, fail('portfolio')),
      // Public visitors may only read approved reviews; admins read everything for moderation.
      onSnapshot(isAdmin ? collection(db, 'reviews') : query(collection(db, 'reviews'), where('status', '==', 'approved')), (s) => {
        const l = toList<GoogleReview>(s); setRawReviews(l); if (!isAdmin) writeCache(CACHE.reviews, l); done('reviews');
      }, fail('reviews')),
    ];
    if (isAdmin) unsubs.push(onSnapshot(collection(db, 'inquiries'), (s) => setInquiries(toList<Inquiry>(s).sort((a, b) => (b.createdAt || '').localeCompare(a.createdAt || ''))), (e) => console.warn('inquiries listener:', e.message)));
    return () => unsubs.forEach((u) => u());
  }, [isAdmin]);

  const isLoading = !timedOut && !(loaded.settings && loaded.services && loaded.portfolio && loaded.reviews);

  // ── Derived public data ──
  const settings = useMemo<SiteSettings>(() => {
    const merged = { ...DEFAULT_SITE_SETTINGS, ...(rawSettings || {}) } as SiteSettings;
    (['heroTitle', 'heroSubtitle', 'heroBadgeText'] as const).forEach((k) => { if (!merged[k] || isLegacyHeroCopy(merged[k])) merged[k] = DEFAULT_SITE_SETTINGS[k]; });
    if (!merged.whatsapp) merged.whatsapp = merged.phone;
    return merged;
  }, [rawSettings]);
  const initialized = settings.initializedCollections || [];
  const estimator = settings.estimator || DEFAULT_ESTIMATOR;

  const services = useMemo<Service[]>(() => {
    if (rawServices && rawServices.length) return [...rawServices].sort((a, b) => (a.order ?? 999) - (b.order ?? 999) || a.name.localeCompare(b.name));
    if (rawServices && initialized.includes('services')) return [];
    return loaded.services || timedOut ? DEFAULT_SERVICES : [];
  }, [rawServices, initialized, loaded.services, timedOut]);

  const portfolio = useMemo<Project[]>(() => {
    const list = (rawPortfolio || []).filter((p) => isAdmin || !isDemoContent(p.id));
    if (list.length) return list;
    if (rawPortfolio && initialized.includes('portfolio')) return [];
    return loaded.portfolio || timedOut ? DEFAULT_PORTFOLIO : [];
  }, [rawPortfolio, initialized, isAdmin, loaded.portfolio, timedOut]);

  const reviews = useMemo<GoogleReview[]>(() => (rawReviews || []).filter((r) => isAdmin || !isDemoContent(r.id)), [rawReviews, isAdmin]);

  // ── Writes (all awaited; errors are thrown with a readable message so the UI can show them) ──
  const markInit = async (name: string) => {
    if ((settingsRef.current?.initializedCollections || []).includes(name)) return;
    await setDoc(doc(db, 'settings', 'global'), { initializedCollections: arrayUnion(name) }, { merge: true });
  };

  const updateSettings = (patch: Partial<SiteSettings>) => wrap(async () => {
    await setDoc(doc(db, 'settings', 'global'), strip({ ...patch, updatedAt: new Date().toISOString() }), { merge: true });
  });

  const saveService = (s: Omit<Service, 'id'> & { id?: string }) => wrap(async () => {
    const id = s.id || `service-${rid()}`;
    await setDoc(doc(db, 'services', id), strip({ ...s, id, order: s.order ?? (rawServices?.length ?? 0) + 1, updatedAt: new Date().toISOString() }));
    await markInit('services');
  });
  const deleteService = (id: string) => wrap(async () => { await deleteDoc(doc(db, 'services', id)); await markInit('services'); });

  const saveProject = (p: Omit<Project, 'id'> & { id?: string }) => wrap(async () => {
    const id = p.id && !p.id.startsWith('placeholder') ? p.id : `project-${rid()}`;
    await setDoc(doc(db, 'portfolio', id), strip({ ...p, id, updatedAt: new Date().toISOString() }));
    await markInit('portfolio');
  });
  const deleteProject = (id: string) => wrap(async () => { await deleteDoc(doc(db, 'portfolio', id)); await markInit('portfolio'); });

  const submitReview = (r: ReviewInput) => wrap(async () => {
    const text = clean(r.reviewText, 1500);
    const seenKey = 'emg_review_hashes';
    const hash = text.toLowerCase().replace(/\s+/g, ' ').slice(0, 200);
    let seen: string[] = []; try { seen = JSON.parse(localStorage.getItem(seenKey) || '[]'); } catch { /* ignore */ }
    if (seen.includes(hash)) throw new Error('This review has already been submitted.');
    throttle('emg_review_log', 60000, 2);
    const id = `review-${rid()}`;
    await setDoc(doc(db, 'reviews', id), {
      authorName: clean(r.authorName, 80), rating: Math.round(r.rating), reviewText: text, serviceReviewed: clean(r.serviceReviewed, 100),
      date: new Date().toISOString(), createdAt: new Date().toISOString(), source: 'customer', status: 'pending', verifiedGoogleReview: false,
    });
    try { localStorage.setItem(seenKey, JSON.stringify([...seen, hash].slice(-20))); } catch { /* ignore */ }
  });
  const addManualReview = (r: Omit<GoogleReview, 'id'>) => wrap(async () => { const id = `review-${rid()}`; await setDoc(doc(db, 'reviews', id), strip({ ...r, id, createdAt: new Date().toISOString() })); });
  const updateReview = (id: string, patch: Partial<GoogleReview>) => wrap(async () => { await setDoc(doc(db, 'reviews', id), strip({ ...patch, updatedAt: new Date().toISOString() }), { merge: true }); });
  const deleteReview = (id: string) => wrap(async () => { await deleteDoc(doc(db, 'reviews', id)); });

  const submitInquiry = (i: InquiryInput) => wrap(async () => {
    throttle('emg_inquiry_log', 30000, 5);
    const id = `inq-${rid()}`;
    await setDoc(doc(db, 'inquiries', id), {
      name: clean(i.name, 80), phone: clean(i.phone, 30) || 'Not provided', email: clean(i.email, 100), service: clean(i.service, 200),
      budget: clean(i.budget, 100), message: clean(i.message, 2000), createdAt: new Date().toISOString(),
    });
  });
  const deleteInquiry = (id: string) => wrap(async () => { await deleteDoc(doc(db, 'inquiries', id)); });

  /** Adds starter content only where nothing exists yet. Never overwrites existing documents. */
  const seedStarterContent = () => wrap(async () => {
    let n = 0;
    const settingsSnap = await getDoc(doc(db, 'settings', 'global'));
    if (!settingsSnap.exists()) { await setDoc(doc(db, 'settings', 'global'), { ...strip(DEFAULT_SITE_SETTINGS), updatedAt: new Date().toISOString() }); n++; }
    for (const s of DEFAULT_SERVICES) {
      const ref = doc(db, 'services', s.id);
      if (!(await getDoc(ref)).exists()) { await setDoc(ref, strip({ ...s, updatedAt: new Date().toISOString() })); n++; }
    }
    await markInit('services');
    if (!settingsSnap.data()?.estimator) await setDoc(doc(db, 'settings', 'global'), { estimator: strip(DEFAULT_ESTIMATOR) }, { merge: true });
    return n;
  }, 90000);

  const exportBackup = () => JSON.stringify({ exportedAt: new Date().toISOString(), settings: rawSettings, services: rawServices, portfolio: rawPortfolio, reviews: rawReviews }, null, 2);
  const importBackup = (json: string) => wrap(async () => {
    const d = JSON.parse(json);
    let n = 0;
    if (d.settings) { await setDoc(doc(db, 'settings', 'global'), strip(d.settings), { merge: true }); n++; }
    for (const [col, list] of [['services', d.services], ['portfolio', d.portfolio], ['reviews', d.reviews]] as const) {
      for (const item of (Array.isArray(list) ? list : []) as { id?: string }[]) { if (item?.id) { await setDoc(doc(db, col, item.id), strip(item)); n++; } }
    }
    return n;
  }, 90000);

  const loginWithGoogle = useCallback(async () => { try { await signInWithPopup(auth, new GoogleAuthProvider()); } catch (e) { throw new Error(explainError(e)); } }, []);
  const logoutUser = useCallback(async () => { await signOut(auth); }, []);

  const value: SiteContextType = {
    settings, estimator, services, portfolio, reviews, inquiries, isLoading, isFirebaseConnected,
    updateSettings, saveService, deleteService, saveProject, deleteProject,
    submitReview, addManualReview, updateReview, deleteReview, submitInquiry, deleteInquiry,
    seedStarterContent, exportBackup, importBackup,
    isAdminOpen, setIsAdminOpen, activeAdminTab, setActiveAdminTab,
    currentUser, isAdmin, isAuthChecking, loginWithGoogle, logoutUser,
  };
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
};

export const useSite = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error('useSite must be used within SiteProvider');
  return c;
};
export type { ReviewStatus };
